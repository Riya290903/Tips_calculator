import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tip Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TipCalculatorScreen(),
    );
  }
}

class TipCalculatorScreen extends StatefulWidget {
  @override
  _TipCalculatorScreenState createState() => _TipCalculatorScreenState();
}

class _TipCalculatorScreenState extends State<TipCalculatorScreen> {
  double _billAmount = 0.0;
  double _tipPercentage = 15.0;

  void _calculateTip() {
    double tipAmount = (_billAmount * _tipPercentage) / 100;
    double totalBill = _billAmount + tipAmount;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Tip Calculator'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Bill Amount: \$${_billAmount.toStringAsFixed(2)}'),
              SizedBox(height: 8),
              Text('Tip Percentage: $_tipPercentage%'),
              SizedBox(height: 8),
              Text('Tip Amount: \$${tipAmount.toStringAsFixed(2)}'),
              SizedBox(height: 8),
              Text('Total Bill: \$${totalBill.toStringAsFixed(2)}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tip Calculator'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Enter Bill Amount',
              ),
              onChanged: (value) {
                setState(() {
                  _billAmount = double.tryParse(value) ?? 0.0;
                });
              },
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Text('Tip Percentage: ${_tipPercentage.toStringAsFixed(0)}%'),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: 30,
                    divisions: 30,
                    value: _tipPercentage,
                    onChanged: (value) {
                      setState(() {
                        _tipPercentage = value;
                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _calculateTip,
              child: Text('Calculate Tip'),
            ),
          ],
        ),
      ),
    );
  }
}
